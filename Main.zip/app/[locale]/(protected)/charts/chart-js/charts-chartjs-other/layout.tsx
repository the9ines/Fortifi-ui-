export const metadata = {
  title: "Chart-js Other Chart ",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
