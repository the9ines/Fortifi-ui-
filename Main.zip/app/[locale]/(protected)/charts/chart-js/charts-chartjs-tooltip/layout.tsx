export const metadata = {
  title: "Chart-js Tooltip Chart ",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
