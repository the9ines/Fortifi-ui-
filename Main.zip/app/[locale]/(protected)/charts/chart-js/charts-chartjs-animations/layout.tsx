export const metadata = {
  title: "Chart-js Animation Chart ",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;