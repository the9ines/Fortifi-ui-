export const metadata = {
  title: "Appex TreeMap Chart ",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
