export const metadata = {
  title: "Appex Heatmap Chart,",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
