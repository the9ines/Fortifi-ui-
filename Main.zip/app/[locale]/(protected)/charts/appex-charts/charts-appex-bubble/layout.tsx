export const metadata = {
  title: "Appex Bubble Chart",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
