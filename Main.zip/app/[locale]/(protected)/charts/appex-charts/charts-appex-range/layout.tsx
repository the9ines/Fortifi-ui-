export const metadata = {
  title: "Appex Range Chart ",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
