export const metadata = {
  title: "Appex Combo Chart",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;

