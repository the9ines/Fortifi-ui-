export const metadata = {
  title: "Appex Funnel Chart",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;

