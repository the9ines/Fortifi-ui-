export const metadata = {
  title: "Appex Bar Chart",
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default Layout;
