
export const mails = [
  {
    id: "fe3aa1aa-c89d-4539-8301-8bf18bd80e87",
    image: [
      {
        image: "/images/avatar/avatar-4.png",
        label: "Mahedi Amin",
        value: "mahedi",
      },
    ],
    title: "laboriosam mollitia et enim quasi adipisci quia provident illum",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "team",
        label: "team",
      },
    ],
  },
  {
    id: "9d7135af-2c69-44f6-a1b5-e7c42126e1e9",
    image: [
      {
        image: "/images/avatar/avatar-2.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
    isDone: false,
    name: "Ester Howard",
    isfav: true,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "low",
        label: "low",
      },
    ],
  },
  {
    id: "fff45fba-157c-4a9a-a839-480e4c94f927",
    image: [
      {
        image: "/images/avatar/avatar-1.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
    isDone: true,
    isfav: true,
    time: "12.00 pm",
    name: "Ester Howard",
    isTrash: false,
    category: [
      {
        value: "medium",
        label: "medium",
      },
      {
        value: "low",
        label: "low",
      },
    ],
  },
  {
    id: "4c5bd598-f951-4a4e-981d-b1f0af0cc917",
    image: [
      {
        image: "/images/avatar/avatar-3.png",
        label: "Mahedi Amin",
        value: "mahedi",
      },
    ],
    title: "illo expedita consequatur quia in",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "high",
        label: "high",
      },
      {
        value: "low",
        label: "low",
      },
    ],
  },
  {
    id: "bc1ad0b1-d6f8-42e1-9689-21c8f2814396",
    image: [
      {
        image: "/images/avatar/avatar-5.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title: "illo expedita consequatur quia in",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "update",
        label: "update",
      },
    ],
  },
  {
    id: "6f4eabf5-e549-4fd1-a24f-87093ebd31be",
    image: [
      {
        image: "/images/avatar/avatar-5.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title: "illo expedita consequatur quia in",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "update",
        label: "update",
      },
    ],
  },
  {
    id: "ed6df190-9141-4048-81d0-1ac067f37e46",
    image: [
      {
        image: "/images/avatar/avatar-5.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title: "illo expedita consequatur quia in",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "update",
        label: "update",
      },
    ],
  },
  {
    id: "a296f702-a7ed-4127-a42a-121669b02b1a",
    image: [
      {
        image: "/images/avatar/avatar-5.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title: "illo expedita consequatur quia in",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "update",
        label: "update",
      },
    ],
  },
  {
    id: "6d4be8c8-a382-4d4a-8df5-a2234e69b57f",
    image: [
      {
        image: "/images/avatar/avatar-5.png",
        label: "Rakibul Islam",
        value: "rakibul",
      },
    ],
    title: "illo expedita consequatur quia in",
    isDone: false,
    name: "Ester Howard",
    isfav: false,
    time: "12.00 pm",
    isTrash: false,
    category: [
      {
        value: "update",
        label: "update",
      }
    ]
  }
];

export type Mail = (typeof mails)[number];
