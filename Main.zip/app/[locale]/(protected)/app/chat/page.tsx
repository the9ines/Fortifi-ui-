import Blank from "./components/blank-chat"
const ChatPage = async () => {
    
    return (
        <Blank />
    )
}

export default ChatPage